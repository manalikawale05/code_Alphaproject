import express from "express";
import db from "../models/db.js";

const router = express.Router();

// ✅ Get user by ID
router.get("/:id", (req, res) => {
  const { id } = req.params;
  db.query("SELECT id, name, email FROM users WHERE id = ?", [id], (err, results) => {
    if (err) return res.status(500).json({ message: "Database error" });
    if (results.length === 0) return res.status(404).json({ message: "User not found" });
    res.json(results[0]);
  });
});

// ✅ Get user by email
router.get("/email/:email", (req, res) => {
  const { email } = req.params;
  db.query("SELECT id, name, email FROM users WHERE email = ?", [email], (err, results) => {
    if (err) return res.status(500).json({ message: "Database error" });
    if (results.length === 0) return res.status(404).json({ message: "User not found" });
    res.json(results[0]);
  });
});

export default router;
