import db from "../models/db.js";

// Get all cart items for a user
export const getCartItems = (req, res) => {
  const userId = req.params.userId;
  const sql = `
    SELECT c.id AS cart_id, p.id AS product_id, p.name, p.price, p.image, c.quantity
    FROM cart c
    JOIN products p ON c.product_id = p.id
    WHERE c.user_id = ?`;

  db.query(sql, [userId], (err, results) => {
    if (err) return res.status(500).json({ message: "Database error" });
    res.status(200).json(results);
  });
};

// Add item to cart
export const addToCart = (req, res) => {
  const { userId, productId, quantity } = req.body;
  if (!userId || !productId)
    return res.status(400).json({ message: "Missing required fields" });

  const checkSql = "SELECT * FROM cart WHERE user_id = ? AND product_id = ?";
  db.query(checkSql, [userId, productId], (err, results) => {
    if (err) return res.status(500).json({ message: "Database error" });

    if (results.length > 0) {
      const newQty = results[0].quantity + (quantity || 1);
      db.query("UPDATE cart SET quantity = ? WHERE id = ?", [newQty, results[0].id]);
      return res.status(200).json({ message: "Cart updated" });
    }

    db.query(
      "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)",
      [userId, productId, quantity || 1],
      (err) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.status(201).json({ message: "Product added to cart" });
      }
    );
  });
};

// Remove item
export const removeFromCart = (req, res) => {
  db.query("DELETE FROM cart WHERE id = ?", [req.params.cartId], (err) => {
    if (err) return res.status(500).json({ message: "Database error" });
    res.status(200).json({ message: "Item removed" });
  });
};

