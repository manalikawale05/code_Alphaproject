import db from "../models/db.js";

// Get all products
export const getAllProducts = (req, res) => {
  db.query("SELECT * FROM products", (err, results) => {
    if (err) return res.status(500).json({ message: "Database error" });
    res.status(200).json(results);
  });
};

// Add a new product
export const addProduct = (req, res) => {
  const { name, price, description, image } = req.body;
  if (!name || !price)
    return res.status(400).json({ message: "Name and price required" });

  db.query(
    "INSERT INTO products (name, price, description, image) VALUES (?, ?, ?, ?)",
    [name, price, description || "", image || ""],
    (err) => {
      if (err) return res.status(500).json({ message: "Database error" });
      res.status(201).json({ message: "Product added successfully!" });
    }
  );
};

